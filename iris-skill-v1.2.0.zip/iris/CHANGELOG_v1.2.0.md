Iris Skill v1.2.0 — contexto de reuniones (resumen + posponer inteligente + prepárame)
